# Tinker CAD
[Abrir projeto](https://www.tinkercad.com/things/hVMXhLXqTN5-multimetro-digital/editel?returnTo=https%3A%2F%2Fwww.tinkercad.com%2Fdashboard%2Fdesigns%2Fcircuits&sharecode=EokfpRQfZYRjVPuFoUjJPjZoX1Xs80rfXPB1WSaAwGQ)
